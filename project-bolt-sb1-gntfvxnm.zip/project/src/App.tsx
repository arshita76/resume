import React, { useState } from 'react';
import { BrainCog } from 'lucide-react';
import { ThemeSwitcher } from './components/ThemeSwitcher';
import { Questionnaire } from './components/Questionnaire';
import { Login } from './components/Login';
import { Portfolio } from './components/Portfolio';
import type { Theme, UserInfo } from './types';

function App() {
  const [theme, setTheme] = useState<Theme>('light');
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isPortfolioVisible, setIsPortfolioVisible] = useState(false);

  const handleLogin = (email: string, password: string) => {
    // Here we'll handle authentication
    setIsLoggedIn(true);
    setUserInfo(prev => ({ ...prev!, email, password }));
  };

  const handleSignup = (name: string, email: string, password: string) => {
    setIsLoggedIn(true);
    setUserInfo({ name, email, password } as UserInfo);
  };

  const handleQuestionnaireComplete = (info: UserInfo) => {
    setUserInfo(prev => ({ ...prev!, ...info }));
  };

  const handlePortfolioUpdate = (field: string, value: string) => {
    setUserInfo(prev => ({ ...prev!, [field]: value }));
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-gray-900 text-white'
          : theme === 'professional'
          ? 'bg-slate-100 text-gray-800'
          : theme === 'creative'
          ? 'bg-gradient-to-br from-red-500 to-violet-600 text-white'
          : 'bg-gradient-to-r from-red-50 to-violet-50 text-gray-800'
      }`}
    >
      <ThemeSwitcher currentTheme={theme} onThemeChange={setTheme} />

      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BrainCog className="w-12 h-12 text-transparent bg-gradient-to-r from-red-600 to-violet-600 bg-clip-text" />
            <h1 className="text-6xl font-bold bg-gradient-to-r from-red-600 to-violet-600 bg-clip-text text-transparent">
              LAKSHYA
            </h1>
          </div>
          <p className="text-xl opacity-80">
            Your AI-powered career companion for the future
          </p>
        </div>

        <div className="flex justify-center items-center">
          {!isLoggedIn ? (
            <Login
              onLogin={handleLogin}
              onSignup={handleSignup}
              onToggleRegister={() => setIsRegistering(!isRegistering)}
              isRegistering={isRegistering}
            />
          ) : !userInfo?.name ? (
            <Questionnaire onComplete={handleQuestionnaireComplete} />
          ) : (
            <div className="bg-white/90 p-8 rounded-xl shadow-xl backdrop-blur-sm max-w-2xl w-full">
              <h2 className="text-2xl font-bold mb-4">Welcome, {userInfo.name}!</h2>
              <p className="mb-4">We're preparing your personalized resume builder experience...</p>
              <button
                onClick={() => setIsPortfolioVisible(true)}
                className="px-6 py-2 bg-gradient-to-r from-red-600 to-violet-600 text-white rounded-lg hover:opacity-90 transition-opacity"
              >
                View Portfolio
              </button>
            </div>
          )}
        </div>
      </div>

      {userInfo && (
        <Portfolio
          userInfo={userInfo}
          visible={isPortfolioVisible}
          onClose={() => setIsPortfolioVisible(false)}
          onUpdate={handlePortfolioUpdate}
        />
      )}
    </div>
  );
}

export default App;