import React from 'react';
import { Palette } from 'lucide-react';
import type { Theme } from '../types';

interface ThemeSwitcherProps {
  currentTheme: Theme;
  onThemeChange: (theme: Theme) => void;
}

const themes: Theme[] = ['light', 'dark', 'professional', 'creative'];

export function ThemeSwitcher({ currentTheme, onThemeChange }: ThemeSwitcherProps) {
  return (
    <div className="fixed top-4 right-4 flex items-center gap-2 bg-white/90 dark:bg-gray-800/90 p-2 rounded-lg shadow-lg backdrop-blur-sm">
      <Palette className="w-5 h-5" />
      <select
        value={currentTheme}
        onChange={(e) => onThemeChange(e.target.value as Theme)}
        className="bg-transparent border-none outline-none text-sm"
      >
        {themes.map((theme) => (
          <option key={theme} value={theme}>
            {theme.charAt(0).toUpperCase() + theme.slice(1)}
          </option>
        ))}
      </select>
    </div>
  );
}