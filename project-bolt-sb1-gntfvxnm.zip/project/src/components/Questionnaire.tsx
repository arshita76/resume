import React, { useState } from 'react';
import type { FormStep, UserInfo } from '../types';

interface QuestionnaireProps {
  onComplete: (info: UserInfo) => void;
}

const steps: FormStep[] = [
  { id: 'name', question: "What's your name?", type: 'text' },
  { id: 'age', question: "What's your age?", type: 'number' },
  { id: 'occupation', question: "What's your current occupation?", type: 'text' },
  { id: 'isStudent', question: "Are you currently a student?", type: 'boolean' },
  { id: 'experience', question: "How many years of experience do you have?", type: 'number' }
];

export function Questionnaire({ onComplete }: QuestionnaireProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<UserInfo>>({});

  const handleAnswer = (answer: any) => {
    const newAnswers = { ...answers, [steps[currentStep].id]: answer };
    setAnswers(newAnswers);

    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(newAnswers as UserInfo);
    }
  };

  const currentQuestion = steps[currentStep];

  return (
    <div className="max-w-lg w-full bg-white dark:bg-gray-800 p-8 rounded-xl shadow-xl">
      <div className="mb-8">
        <div className="flex gap-2 mb-4">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`h-2 flex-1 rounded-full ${
                index <= currentStep ? 'bg-blue-500' : 'bg-gray-200 dark:bg-gray-700'
              }`}
            />
          ))}
        </div>
        <h2 className="text-2xl font-bold mb-2">{currentQuestion.question}</h2>
      </div>

      <div className="space-y-4">
        {currentQuestion.type === 'boolean' ? (
          <div className="flex gap-4">
            <button
              onClick={() => handleAnswer(true)}
              className="flex-1 py-3 px-6 bg-green-500 text-white rounded-lg hover:bg-green-600"
            >
              Yes
            </button>
            <button
              onClick={() => handleAnswer(false)}
              className="flex-1 py-3 px-6 bg-red-500 text-white rounded-lg hover:bg-red-600"
            >
              No
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <input
              type={currentQuestion.type}
              className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600"
              placeholder="Your answer"
              onChange={(e) => handleAnswer(
                currentQuestion.type === 'number' ? Number(e.target.value) : e.target.value
              )}
              onKeyPress={(e) => e.key === 'Enter' && handleAnswer(e.currentTarget.value)}
            />
            <button
              onClick={() => handleAnswer((document.querySelector('input') as HTMLInputElement).value)}
              className="w-full py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
}