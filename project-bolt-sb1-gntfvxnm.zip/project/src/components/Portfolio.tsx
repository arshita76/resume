import React, { useState } from 'react';
import { Edit2, Check, X } from 'lucide-react';
import { UserInfo, VocabularyError } from '../types';
import { checkVocabulary } from '../utils/vocabulary';

interface PortfolioProps {
  userInfo: UserInfo;
  visible: boolean;
  onClose: () => void;
  onUpdate: (field: string, value: string) => void;
}

export function Portfolio({ userInfo, visible, onClose, onUpdate }: PortfolioProps) {
  const [editingField, setEditingField] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [vocabularyErrors, setVocabularyErrors] = useState<VocabularyError[]>([]);

  const handleEdit = (field: string, value: string) => {
    setEditingField(field);
    setEditValue(value);
  };

  const handleSave = async (field: string) => {
    const errors = await checkVocabulary(editValue);
    if (errors.length > 0) {
      setVocabularyErrors(errors);
      return;
    }
    onUpdate(field, editValue);
    setEditingField(null);
    setVocabularyErrors([]);
  };

  return (
    <div
      className={`fixed inset-y-0 right-0 w-96 bg-white shadow-2xl transform transition-transform duration-300 ease-in-out ${
        visible ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      <div className="h-full overflow-y-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-violet-600 bg-clip-text text-transparent">
            Your Portfolio
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ×
          </button>
        </div>
        
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-red-50 to-violet-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-800 mb-2">Personal Info</h3>
            {Object.entries(userInfo).map(([field, value]) => (
              field !== 'password' && (
                <div key={field} className="mb-2">
                  <div className="flex items-center justify-between">
                    <p className="text-gray-600 capitalize">
                      {field}: {editingField === field ? (
                        <input
                          type="text"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          className="border rounded px-2 py-1"
                        />
                      ) : (
                        value
                      )}
                    </p>
                    <div className="flex gap-2">
                      {editingField === field ? (
                        <>
                          <button
                            onClick={() => handleSave(field)}
                            className="text-green-600 hover:text-green-700"
                          >
                            <Check size={16} />
                          </button>
                          <button
                            onClick={() => setEditingField(null)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X size={16} />
                          </button>
                        </>
                      ) : (
                        <button
                          onClick={() => handleEdit(field, String(value))}
                          className="text-gray-600 hover:text-gray-700"
                        >
                          <Edit2 size={16} />
                        </button>
                      )}
                    </div>
                  </div>
                  {vocabularyErrors.length > 0 && editingField === field && (
                    <div className="mt-2 text-sm text-red-600">
                      {vocabularyErrors.map((error, index) => (
                        <p key={index}>
                          Suggestion: Replace "{error.word}" with "{error.suggestion}"
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              )
            ))}
          </div>

          <div className="bg-gradient-to-r from-red-50 to-violet-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-800 mb-2">Resume Templates</h3>
            <div className="grid grid-cols-2 gap-4">
              {resumeTemplates.map((template) => (
                <div
                  key={template.id}
                  className="p-3 border rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                >
                  <img
                    src={template.preview}
                    alt={template.name}
                    className="w-full h-32 object-cover rounded mb-2"
                  />
                  <h4 className="font-medium text-sm">{template.name}</h4>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const resumeTemplates = [
  {
    id: 'modern',
    name: 'Modern Professional',
    description: 'Clean and contemporary design',
    preview: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&q=80&w=300'
  },
  {
    id: 'creative',
    name: 'Creative Portfolio',
    description: 'Stand out with style',
    preview: 'https://images.unsplash.com/photo-1626785774625-0b1c2c4efd7c?auto=format&fit=crop&q=80&w=300'
  }
];