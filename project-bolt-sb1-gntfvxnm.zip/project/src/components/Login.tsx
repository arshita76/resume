import React, { useState } from 'react';
import { Mail, Lock, User } from 'lucide-react';

interface LoginProps {
  onLogin: (email: string, password: string) => void;
  onSignup: (name: string, email: string, password: string) => void;
  onToggleRegister: () => void;
  isRegistering: boolean;
}

export function Login({ onLogin, onSignup, onToggleRegister, isRegistering }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegistering) {
      onSignup(name, email, password);
    } else {
      onLogin(email, password);
    }
  };

  return (
    <div className="bg-white/90 p-8 rounded-2xl shadow-xl backdrop-blur-sm w-full max-w-md">
      <h2 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-red-600 to-violet-600 bg-clip-text text-transparent">
        {isRegistering ? 'Create Account' : 'Welcome to LAKSHYA'}
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {isRegistering && (
          <div className="space-y-2">
            <div className="relative">
              <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                required
              />
            </div>
          </div>
        )}
        <div className="space-y-2">
          <div className="relative">
            <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-violet-500 focus:border-transparent"
              required
            />
          </div>
        </div>
        <button
          type="submit"
          className="w-full py-3 bg-gradient-to-r from-red-600 to-violet-600 text-white rounded-lg hover:opacity-90 transition-opacity"
        >
          {isRegistering ? 'Sign Up' : 'Sign In'}
        </button>
      </form>
      <p className="mt-4 text-center text-gray-600">
        {isRegistering ? 'Already have an account?' : "Don't have an account?"}{' '}
        <button
          onClick={onToggleRegister}
          className="text-violet-600 hover:text-violet-700 font-semibold"
        >
          {isRegistering ? 'Sign In' : 'Sign Up'}
        </button>
      </p>
    </div>
  );
}