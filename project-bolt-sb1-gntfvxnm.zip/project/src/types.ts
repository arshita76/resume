export type Theme = 'light' | 'dark' | 'professional' | 'creative';

export interface UserInfo {
  name: string;
  age: number;
  occupation: string;
  isStudent: boolean;
  experience: number;
  email: string;
  password: string;
}

export interface FormStep {
  id: string;
  question: string;
  type: 'text' | 'number' | 'boolean' | 'select' | 'password';
  options?: string[];
}

export interface PortfolioSection {
  title: string;
  content: string;
  isEditing?: boolean;
}

export interface ResumeTemplate {
  id: string;
  name: string;
  description: string;
  preview: string;
}

export interface VocabularyError {
  word: string;
  suggestion: string;
  context: string;
}