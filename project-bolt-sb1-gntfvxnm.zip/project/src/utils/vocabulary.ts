export async function checkVocabulary(text: string): Promise<Array<{ word: string; suggestion: string; context: string }>> {
  // This is a simple example. In a real application, you would use an API
  const commonErrors = {
    'definately': 'definitely',
    'seperate': 'separate',
    'occured': 'occurred',
    'recieve': 'receive',
    'accomodate': 'accommodate',
    'begining': 'beginning',
    'buisness': 'business',
    'commited': 'committed',
    'completly': 'completely',
    'neccessary': 'necessary'
  };

  const errors = [];
  const words = text.toLowerCase().split(/\s+/);

  for (const word of words) {
    if (word in commonErrors) {
      errors.push({
        word,
        suggestion: commonErrors[word as keyof typeof commonErrors],
        context: text
      });
    }
  }

  return errors;
}